/- Modified for the Palomar submission: module header, public imports,
and exposed public declarations. Original proof bodies are retained.
See MODULE_MIGRATION.json for the checkpoint and ported file hashes. -/
module

public import KakeyaSharp.Moore.Elliptic
public import KakeyaSharp.QuaternionPositive

@[expose] public section

/-! The faithful complex representation preserves the actual quaternionic quadratic form. -/

noncomputable section

namespace KakeyaSharp.Moore

open scoped MatrixOrder ComplexOrder
open Matrix KakeyaSharp.QuaternionAlgebra

/-- The first column of the complex representation identifies a quaternion vector with
the full complex vector space of twice the dimension. -/
def complexVector {n : ℕ} (z : Fin n → Quaternion ℝ) : Fin n × Fin 2 → ℂ :=
  fun i ↦ quaternionMatrix (z i.1) i.2 0

def quaternionVector {n : ℕ} (v : Fin n × Fin 2 → ℂ) : Fin n → Quaternion ℝ :=
  fun i ↦ ⟨(v (i, 0)).re, (v (i, 0)).im, -(v (i, 1)).re, (v (i, 1)).im⟩

@[simp] theorem complexVector_quaternionVector {n : ℕ} (v : Fin n × Fin 2 → ℂ) :
    complexVector (quaternionVector v) = v := by
  funext ⟨i, a⟩
  fin_cases a <;> apply Complex.ext <;> simp [complexVector, quaternionVector, quaternionMatrix]

@[simp] theorem quaternionVector_complexVector {n : ℕ} (z : Fin n → Quaternion ℝ) :
    quaternionVector (complexVector z) = z := by
  funext i
  ext <;> simp [complexVector, quaternionVector, quaternionMatrix]

@[simp] theorem complexVector_zero (n : ℕ) : complexVector (0 : Fin n → Quaternion ℝ) = 0 := by
  funext ⟨i, a⟩
  fin_cases a <;> apply Complex.ext <;> simp [complexVector, quaternionMatrix]

@[simp] theorem quaternionVector_zero (n : ℕ) :
    quaternionVector (0 : Fin n × Fin 2 → ℂ) = 0 := by
  funext i
  ext <;> simp [quaternionVector]

theorem complexVector_injective (n : ℕ) :
    Function.Injective (complexVector (n := n)) :=
  Function.LeftInverse.injective quaternionVector_complexVector

theorem quaternionVector_injective (n : ℕ) :
    Function.Injective (quaternionVector (n := n)) :=
  Function.LeftInverse.injective complexVector_quaternionVector

theorem quaternionMatrix_triple_entry (p q r : Quaternion ℝ) :
    quaternionMatrix (star p * q * r) 0 0 =
      ∑ a : Fin 2, ∑ b : Fin 2,
        star (quaternionMatrix p a 0) * quaternionMatrix q a b * quaternionMatrix r b 0 := by
  rw [quaternionMatrix_mul, quaternionMatrix_mul, quaternionMatrix_star]
  simp only [Matrix.mul_apply, Matrix.conjTranspose_apply, Finset.sum_mul]
  rw [Finset.sum_comm]

/-- Exact complex-valued quadratic-form identity, before taking real parts. -/
theorem complexVector_quadratic {n : ℕ} (A : Matrix (Fin n) (Fin n) (Quaternion ℝ))
    (z : Fin n → Quaternion ℝ) :
    star (complexVector z) ⬝ᵥ complexify A *ᵥ complexVector z =
      quaternionMatrix (∑ i, ∑ j, star (z i) * A i j * z j) 0 0 := by
  change _ = quaternionMatrixHom (∑ i, ∑ j, star (z i) * A i j * z j) 0 0
  simp only [map_sum, Matrix.sum_apply]
  change _ = ∑ i, ∑ j, quaternionMatrix (star (z i) * A i j * z j) 0 0
  simp only [quaternionMatrix_triple_entry]
  simp only [dotProduct, Matrix.mulVec, Fintype.sum_prod_type, Finset.mul_sum,
    complexVector, complexify, Pi.star_apply, mul_assoc]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.sum_comm]

theorem complexVector_quadratic_re {n : ℕ} (A : Matrix (Fin n) (Fin n) (Quaternion ℝ))
    (z : Fin n → Quaternion ℝ) :
    (star (complexVector z) ⬝ᵥ complexify A *ᵥ complexVector z).re =
      KakeyaSharp.quaternionForm A z := by
  rw [complexVector_quadratic]
  change (∑ i, ∑ j, star (z i) * A i j * z j).re = KakeyaSharp.quaternionForm A z
  simp only [KakeyaSharp.quaternionForm, Matrix.mulVec, dotProduct, Finset.mul_sum, mul_assoc]

theorem hermitian_quadratic_im {ι : Type*} [Fintype ι]
    {A : Matrix ι ι ℂ} (hA : A.IsHermitian) (v : ι → ℂ) :
    (star v ⬝ᵥ A *ᵥ v).im = 0 := by
  have h := congrArg Complex.im (hA.star_dotProduct_mulVec_comm v v)
  simp only [Complex.star_def, Complex.conj_im] at h
  linarith

/-- Positivity in the complex representation is precisely positivity of the original
quaternionic form, not an additional analytic assumption. -/
theorem complexify_posSemidef_iff {n : ℕ}
    {A : Matrix (Fin n) (Fin n) (Quaternion ℝ)} (hA : A.IsHermitian) :
    (complexify A).PosSemidef ↔ ∀ z, 0 ≤ KakeyaSharp.quaternionForm A z := by
  constructor
  · intro h z
    have hz := h.dotProduct_mulVec_nonneg (complexVector z)
    have hre := (Complex.nonneg_iff.mp hz).1
    simpa only [complexVector_quadratic_re] using hre
  · intro h
    refine Matrix.PosSemidef.of_dotProduct_mulVec_nonneg (complexify_isHermitian hA) ?_
    intro v
    apply Complex.nonneg_iff.mpr
    constructor
    · have hz := h (quaternionVector v)
      rwa [← complexVector_quadratic_re, complexVector_quaternionVector] at hz
    · exact (hermitian_quadratic_im (complexify_isHermitian hA) v).symm

theorem complexify_posDef_iff {n : ℕ}
    {A : Matrix (Fin n) (Fin n) (Quaternion ℝ)} (hA : A.IsHermitian) :
    (complexify A).PosDef ↔ ∀ z ≠ 0, 0 < KakeyaSharp.quaternionForm A z := by
  constructor
  · intro h z hz
    have hcz : complexVector z ≠ 0 := by
      intro heq
      exact hz ((complexVector_injective n) (heq.trans (complexVector_zero n).symm))
    have hq := h.dotProduct_mulVec_pos hcz
    have hre := (Complex.pos_iff.mp hq).1
    simpa only [complexVector_quadratic_re] using hre
  · intro h
    refine Matrix.PosDef.of_dotProduct_mulVec_pos (complexify_isHermitian hA) ?_
    intro v hv
    have hqv : quaternionVector v ≠ 0 := by
      intro heq
      exact hv ((quaternionVector_injective n) (heq.trans (quaternionVector_zero n).symm))
    apply Complex.pos_iff.mpr
    constructor
    · have hz := h (quaternionVector v) hqv
      rwa [← complexVector_quadratic_re, complexVector_quaternionVector] at hz
    · exact (hermitian_quadratic_im (complexify_isHermitian hA) v).symm


end KakeyaSharp.Moore

